import { logger } from '../log/logger.js';

export const Base = class {
}
