export const validate = (url) => {
  return url.indexOf('javascript:') != 0;
}
